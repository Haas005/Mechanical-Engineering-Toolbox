# Beam calculator

Shear, moment, slope and deflection for single-span beams, built on SymPy's
`Beam` class with a Streamlit interface.

## Run it

    pip install -r requirements.txt
    streamlit run app.py

## Files

- `beam_solver.py`      the engine (no UI code); `solve_beam()` returns a `BeamResult`
- `app.py`              the Streamlit interface
- `test_beam_solver.py` checks the solver against textbook formulas (`python test_beam_solver.py`)

## Supports
Simply supported, cantilever, propped cantilever, fixed-fixed.

## Loads
Point loads, distributed (uniform, partial-span) loads, applied moments.

## Sign convention
- Loads positive downward; applied moments positive counter-clockwise
- Shear positive when the left segment is pushed up; moment positive when sagging
- Deflection positive upward (a sagging beam has negative deflection)

## Limits
Prismatic beam (constant EI), small deflections, linear elastic, no axial load.
Triangular/trapezoidal loads are not in the UI yet (SymPy supports them with
`apply_load(value, start, 1, end=...)`).
